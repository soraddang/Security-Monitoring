rifiuti2 is designed to run as portable command line
application, and no installation is required. Extract zip
file onto any folder of your choice and programs are ready
for use.

It is released under Revised BSD License.

All documents are available online:

- Detailed usage help:
https://github.com/abelcheung/rifiuti2/wiki/Usage-and-Examples

- Official GitHub repository:
https://github.com/abelcheung/rifiuti2/

- Extra news and technical info:
https://abelcheung.github.io/rifiuti2/
